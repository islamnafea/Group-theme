<body>
   <!-- Brand Start -->
        <div class="brand">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-3 col-md-4">

                    </div>
                    <div class="col-lg-6 col-md-4">
                        <div class="b-ads">
                            <a href="https://code95.com">
                                <img src="<?php echo get_template_directory_uri(); ?>/img/ads-1.jpg" alt="Ads">
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-4">

                    </div>
                </div>
            </div>
        </div>
        <!-- Brand End -->

        <!-- Nav Bar Start -->
        <div class="nav-bar">
            <div class="container">

                <nav class="navbar navbar-expand-md bg-dark navbar-dark">
                    <a href="#" class="navbar-brand">Code95</a>
                    <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                            <?php wp_nav_menu(array( 
                           'theme_location'  => 'primary', 
                           'menu_class'  => 'navbar-nav mr-auto',
                           'container_class' => 'collapse navbar-collapse justify-content-between',
                           'container_id' => 'navbarCollapse',
                           'walker' => new WP_Bootstrap_Navwalker()
)); ?>
                        <div class="col-lg-3 col-md-4">
                            <div class="b-search">
                                <input type="text" placeholder="Search">
                                <button><i class="fa fa-search"></i></button>
                            </div>
                        </div>
                </nav>
                </div>
            </div>
        </div>
        <!-- Nav Bar End -->
