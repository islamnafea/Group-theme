<?php
             $cat_name = get_theme_mod('name_news_category');
             $cat_id = get_theme_mod('slider_news_category');
                     $news = array(
                          'post_type' => 'post',
                          'posts_per_page' => 5,
                          'order' => 'DESC',
                          'cat' =>  $cat_id
                          );
                       $posts = new WP_query($news);
                       if ($posts->have_posts()) {?>

        <div class="cat-news">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h2><?php echo $cat_name ?></h2>
                        <div class="row cn-slider">
                        <?php 
                            while($posts->have_posts()) { 
                            $posts->the_post(); ?>
                            <div class="col-md-3">
                                <div class="cn-img">
                                    <img src="<?php the_post_thumbnail_url();?>" />
                                    <div class="cn-title">
                                        <a href="<?php the_permalink();?>"><?php the_title();?></a>
                                    </div>
                                </div>
                            </div>
                            <?php }?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
       <?php } else{} ?>