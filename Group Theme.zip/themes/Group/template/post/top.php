 <!-- Top News Start-->
        <div class="top-news">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 tn-left">
                        <div class="row">
                            <div class="col-md-7 mb-col">
                                <div class="tn-img" style="height: 100%;">
                                    <img src="<?php the_post_thumbnail_url();?>" />
                                    <div class="tn-title">
                                        <a href="<?php the_permalink();?>"><?php the_title();?></a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-5" style="padding-left: 5px;">
                     <?php
                     $news = array(
                          'post_type' => 'post',
                          'posts_per_page' => 1,
                          'order' => 'DESC',
                          'offset' => 1
                          );
      
                       $posts = new WP_query($news);
                       if ($posts->have_posts()) {
                       while($posts->have_posts()) {
                      $posts->the_post(); ?>                            
                            
                           
                            <div class="col-md-12" style="padding-bottom: 5px;">
                                <div class="tn-img">
                                    <img src="<?php the_post_thumbnail_url();?>" />
                                    <div class="tn-title">
                                        <a href="<?php the_permalink();?>"><?php the_title();?></a>
                                    </div>
                                </div>
                            </div>
                     <?php }}?>
                     <?php
                        $news = array(
                        'post_type' => 'post',
                        'posts_per_page' => 1,
                        'order' => 'DESC',
                        'offset' => 2
                        );
      
                    $posts = new WP_query($news);
                    if ($posts->have_posts()) {
                    while($posts->have_posts()) {
                   $posts->the_post(); ?>
                            
                            <div class="col-md-12" >
                                <div class="tn-img">
                                    <img src="<?php the_post_thumbnail_url();?>" />
                                    <div class="tn-title">
                                        <a href="<?php the_permalink();?>"><?php the_title();?></a>
                                    </div>
                                </div>
                            </div>
                            <?php }}?>
                          </div>
                        </div>
                    </div>
                    <div class="col-md-4 tn-right">
                                <a href="htttps://code95.com">
                                    <img src="<?php echo get_template_directory_uri(); ?>/img/adds.png" alt="Ads" style="width: 100%;">
                                </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Top News End-->