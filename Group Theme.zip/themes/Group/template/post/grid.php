        <div class="main-news">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8">
                        <h2>Features</h2>
                        <div class="row">
                        <?php
                            $args = array( 
                                'post_type' => 'post',
                                'posts_per_page' => 2,
                                'order' => 'DESC',
                                'meta_key' => 'view_the_post',
                                'meta_value' => "Yes"
                                );
                           $posts = new WP_query($args);
                              if ($posts->have_posts()) { ?>
                             <?php while($posts->have_posts()) {
                              $posts->the_post(); ?>
                            <div class="col-md-6">
                                <div class="mn-img">
                                    <img src="<?php the_post_thumbnail_url();?>" />
                                    <div class="mn-title">
                                        <a href="<?php the_permalink();?>"><?php the_title();?></a>
                                    </div>
                                </div>
                            </div>
                            <?php }}?>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="mn-list">
                            <h2>Top 5 Stories</h2>
                            <ul>
                         <?php
                            $args = array(
                                'post_type' => 'post',
                                'meta_key' => 'views_daily',
                                'orderby' => 'meta_value_num',
                                'order' => 'DESC',
                                'posts_per_page' => '3',
                                );
                            $posts = new WP_query($args);
                                if ($posts->have_posts()) { ?> 
                        <?php 
                        while($posts->have_posts()) { 
                            $posts->the_post(); ?>
                        <?php }}?>
                             <li><a href="<?php the_permalink();?>"><?php the_title();?></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>