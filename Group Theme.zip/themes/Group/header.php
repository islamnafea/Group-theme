<?php

get_template_part('template/header/head');
get_template_part('template/header/nav');





?>





