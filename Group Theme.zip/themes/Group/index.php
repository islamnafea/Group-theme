<?php get_header(); ?>

<?php
// Top News Start
    get_template_part('template/post/top');
# Top News End

// Slider News Start
    get_template_part('template/post/slider','', $args);
# Slider News End

// Slider News Start
    get_template_part('template/post/grid','', $args);
# Slider News End

// Slider News Start
    get_template_part('template/post/views','', $args);
# Slider News End

?>

<?php get_footer(); ?>