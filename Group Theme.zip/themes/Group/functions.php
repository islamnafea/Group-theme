<?php

    function menue_setup() {
		register_nav_menus(
			array(
				'primary' => esc_html__( 'Primary menu', 'code95' ),
			)
		);
    }
		
		add_action( 'after_setup_theme', 'menue_setup' );
		
		add_theme_support( 'post-thumbnails' );
		
		include 'inc/class-wp-bootstrap-navwalker.php';
		


function topnews_customize_register($wp_customize ) {
	require_once get_stylesheet_directory() . '/dropdown-category.php';
	
	$wp_customize->add_panel( 'themes_options', array(
		'title' => esc_html_x( 'Themes Options', 'customizer section title', 'code95' ),
	) );

	$wp_customize->add_section( 'homepage', array(
		'title' => esc_html_x( 'Home Settings', 'customizer section title', 'code95' ),
		'panel' => 'themes_options',
	) );
	
			$wp_customize->add_setting( 'name_news_category', array(
		'default'        => 'Egypt News',

	) );
        $wp_customize->add_control('name_news_category_text', array(
        'label'      => __('Section Name', 'themename'),
        'section'    => 'homepage',
        'settings'   => 'name_news_category', ) );

	$wp_customize->add_setting( 'slider_news_category', array(
		'default'           => 0,
		'sanitize_callback' => 'absint',
	) );

	$wp_customize->add_control( new My_Dropdown_Category_Control( $wp_customize, 'slider_news_category', array(
		'section'       => 'homepage',
		'label'         => esc_html__( 'Slider posts category', 'code95' ),
		'description'   => esc_html__( 'Select the category that the slider will show posts from. If no category is selected, the slider will be disabled.', 'code95' ),
	) ) );
	

}


add_action('customize_register', 'topnews_customize_register');



function custom_wpp_update_postviews($postid) {
    // Accuracy:
    //   10  = 1 in 10 visits will update view count. (Recommended for high traffic sites.)
    //   30  = 30% of visits. (Medium traffic websites.)
    //   100 = Every visit. Creates many db write operations every request.

    $accuracy = 50;

    if ( function_exists('wpp_get_views') && (mt_rand(0,100) < $accuracy) ) {
        // Remove or comment out lines that you won't be using!!
        update_post_meta(
            $postid,
            'views_total',
            wpp_get_views($postid, 'all', false)
        );
        update_post_meta(
            $postid,
            'views_daily',
            wpp_get_views($postid, 'daily', false)
        );
        update_post_meta(
            $postid,
            'views_weekly',
            wpp_get_views($postid, 'weekly', false)
        );
        update_post_meta(
            $postid,
            'views_monthly',
            wpp_get_views($postid, 'monthly', false)
        );
    }
}
add_action('wpp_post_update_views', 'custom_wpp_update_postviews');

		
		
?>