<?php return array('dependencies' => array(), 'version' => '1fee0e8d43b6337ca2ff');
